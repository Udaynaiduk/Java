source /opt/concourse-java.sh
setup_symlinks