package com.threading;

public class HelloThread extends Thread {
	// step-1 extend thread class to u r class
	// step-2 override run method

	// @override kept bcz run method avlbl in Thread class which
	// is parent of our sub class
	// Why run method ?
	// You should write u r business logic inside run method only
	@Override
	public void run() {
		for (int i = 0; i < 5; i++) {
			try {
//				Thread.sleep(100);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Hello");
//			System.out.println("My thread name is ::" + Thread.currentThread().getName());
//			System.out.println("Priority of Thread is **" + Thread.currentThread().getPriority());
		}
	}

}
