package com.threading;

public class MultiThreadDemo {

	public static void main(String[] args) throws InterruptedException {
		
		HelloThread ht=new HelloThread();
		
		GoodMorning gm=new GoodMorning();
		
		GoodEvening ge=new GoodEvening();
		Thread t=new Thread(ge);
		t.start();
		
		gm.start();// TS register
		//
		ht.start();// a new thread context will be created and the code inside tun method will be exec in that thread
		
//		ht.run();// new thread wont be created
		// it will run in the same thread
		
		Thread.currentThread().setPriority(10);
		for (int i = 0; i < 10; i++) {
			//it will make the thread to wait for given amount of time in ms
//			Thread.sleep(100);
			System.out.println("Hi");
//			System.out.println("Priority of Thread is **"+Thread.currentThread().getPriority());
//			System.out.println("My thread name is ::"+Thread.currentThread().getName());
		}
	}

	private static void mainThread() {
		Thread myCurrentThreadObject = Thread.currentThread();
		String myThreadName = myCurrentThreadObject.getName();
		System.out.println("My current thread name is: "+myThreadName);
	}
	
	void m3() {
		System.out.println("m3");
	}

}
