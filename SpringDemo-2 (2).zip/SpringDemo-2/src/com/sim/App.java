package com.sim;

import java.sql.SQLException;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class App {

	public static void main(String[] args) throws SQLException {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		JdbcTemplate jdbcTemplate = ctx.getBean("jdbcTemplate", JdbcTemplate.class);
		Object[] inputArgs = { 12 };
//		int rowsInserted = jdbcTemplate.update("INSERT INTO sim VALUES(?,?)", inputArgs);
//		int rowsInserted = jdbcTemplate.update("update sim set sim_number=? where sim_id=?", inputArgs);
//		int rowsInserted = jdbcTemplate.update("delete from sim where sim_id=?", inputArgs);
		// single record reader , multi record reader with dynamic inputs
		Sim simObj= jdbcTemplate.queryForObject("select * from sim where sim_id=? ",inputArgs, new SimRowMapper());
		System.out.println(simObj);
//		System.out.println(rowsInserted);
	}

	private static void staticCrudOps(JdbcTemplate jdbcTemplate) {
		System.out.println("jdbcTemplate loaded !!");
//		int rowsInserted = jdbcTemplate.update("INSERT INTO sim VALUES(12,98480)");
//		int rowsInserted = jdbcTemplate.update("update sim set sim_number=1 where sim_id=6");
//		int rowsInserted = jdbcTemplate.update("delete from sim where sim_id=6");
		List<Sim> listSimcards = jdbcTemplate.query("select * from sim ", new SimRowMapper());
		System.out.println(listSimcards);
	}

}
