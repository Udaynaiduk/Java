package com.sim;

public class Sim {
	
	private int id;
	
	private int no;

	public int getSimId() {
		return id;
	}

	public void setSimNo(int simId) {
		this.id = simId;
	}

	public int getSimNumber() {
		return no;
	}

	public void setSimNumber(int simNumber) {
		this.no = simNumber;
	}

	@Override
	public String toString() {
		return "Sim [simId=" + id + ", simNumber=" + no + "]";
	}
	
	

}
