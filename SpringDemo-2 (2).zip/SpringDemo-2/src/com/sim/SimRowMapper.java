package com.sim;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class SimRowMapper implements RowMapper<Sim>{

	@Override
	public Sim mapRow(ResultSet rs, int rowNum) throws SQLException {
		Sim sim=new Sim();
		sim.setSimNo(rs.getInt(1));
		sim.setSimNumber(rs.getInt(2));
		return sim;
	}

}
