package com.sim.copy;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration // beans.xml
@ComponentScan(basePackages = "com")
@PropertySource(value = "classpath:app.properties")
public class AkashConfig {
	
	@Bean("dataSource")
	public DataSource getDataSource() {
		DriverManagerDataSource ds=new DriverManagerDataSource();
		ds.setUrl("jdbc:mysql://localhost:3306/flm");
		ds.setUsername("root");
		ds.setPassword("root");
		return ds;
	}
	
	@Bean("jdbcTemplate")
	public  JdbcTemplate getJdbcTemplate() {
		DataSource dataSource = getDataSource();
		JdbcTemplate jdbc=new JdbcTemplate(dataSource);
		return jdbc;
	}
	
	

}
