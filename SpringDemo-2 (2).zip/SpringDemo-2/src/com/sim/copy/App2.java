package com.sim.copy;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.sim.Sim;
import com.sim.SimRowMapper;

public class App2 {

	public static void main(String[] args) {
		System.out.println("**");
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AkashConfig.class);
		JdbcTemplate jdbcTemplate = ctx.getBean("jdbcTemplate",JdbcTemplate.class);
		int rowsInserted = jdbcTemplate.update("insert into sim values(332,333)");
		
		System.out.println("Done");
	}

}
