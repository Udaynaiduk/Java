package com.sim;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Student {
	
	@Autowired
	Address adr;

	@Value("${id}")
	int id;

	@Value("${name}")
	String name;// ref

	
	// 8
	// b s i l d b f c

	public int getId() {
		return id;
	}

	public void setId(int id) {
		System.out.println("Setter method invoked !!");
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Student(int id) {
		System.out.println("Const injection invoked !!");
		this.id = id;
	}

	public Student(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Student() {
		System.out.println("Const invoked !!");
	}

	public void Student2() {
		System.out.println("postcccc");
	}
	

}
