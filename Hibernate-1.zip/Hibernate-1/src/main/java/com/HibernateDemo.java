package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateDemo {

	public static void main(String[] args)  {
		
		//Config
		// db
		// url
		//uname 
		//pw
		
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(User.class);
		
		System.out.println("Config loaded");
		
		//SF
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		
		//3
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		User u1=new User(15, "Satya", 95);
		
		// insert into user values(1,'upendra',99);
		session.save(u1); // Create
		
		// select * from users where id=1;
		User user = session.get(User.class, 1);//Read
		
		
		System.out.println(user);
		transaction.commit();
		System.out.println("Saved");
		
		
		
		//DriverManger
		//Connection
		// insert into user values(1,'upendra',99);
		// statement / ps 
		// executeUpdate
	}
}
