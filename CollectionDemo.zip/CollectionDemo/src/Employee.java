
public class Employee {
	int id;
	String name;

	public Employee(int id) {
		this.id = id;
	}
	
	

}
