import java.util.ArrayList;
import java.util.Scanner;

public class ListWithScanner {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ArrayList<String> al=new ArrayList<>();
		//5 items 
		
		for (int i = 1; i < 5; i++) {
			System.out.println("Enter data point");
			String data=sc.next();
			al.add(data);
			
		}
		System.out.println("My list data is ");
		System.out.println(al);

	}

}
