public class Test {

	public static void main(String[] args) {

		StringBuffer strBuff = new StringBuffer("null");

		StringBuilder strBul = new StringBuilder("null");

		String str = new String();

		str = "null";

		System.out.print(str.equals(strBul) + " ");

		System.out.print(strBul.equals(strBuff) + " ");

		System.out.print(strBul.equals(str));
	}
}
