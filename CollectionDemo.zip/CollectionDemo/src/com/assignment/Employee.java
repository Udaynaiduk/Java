package com.assignment;

public class Employee {

}
