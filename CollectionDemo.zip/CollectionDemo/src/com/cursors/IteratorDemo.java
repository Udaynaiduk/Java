package com.cursors;

import java.util.ArrayList;
import java.util.Iterator;

public class IteratorDemo {

	public static void main(String[] args) {

		ArrayList<String> al = new ArrayList<>();
		al.add("FLM");
		al.add("Spring");
		al.add("Java");
		al.add("SpringBoot");
		al.add("MicroServices"); // 0-4

		// getting iterator Object
		// Iterator can go in only one direction
		// This can't add any new elements
		// Can remove using remove method.
		Iterator<String> itr = al.iterator();

		while (itr.hasNext()) {
			String data = itr.next();
			if (data.equals("MicroServices") || data.equals("FLM")) {
				itr.remove();
			} else {
				System.out.println(data);
			}
		}
		System.out.println("_______");
		System.out.println(al);

	}

}
