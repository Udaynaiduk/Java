package com.cursors;

import java.util.ArrayList;
import java.util.ListIterator;

public class ListIteratorDemo {

	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<>();
		al.add("FLM");
		al.add("Spring");
		al.add("Java");
		al.add("SpringBoot");
		al.add("MicroServices");
		
		// it can traverse fwd and reverse direction
		// it can add/set and remove as well
		ListIterator<String> li = al.listIterator();
		
		while(li.hasNext()) {
			System.out.println(li.nextIndex());
			String data = li.next();
			if(data.equals("FLM")) {
				li.set("FrontlinesMedia");
			}
			System.out.println(data);
		}
		li.add("SystemDesign");
		System.out.println(al);
		System.out.println("________");
		while(li.hasPrevious()) {
			System.out.println(li.previous());
		}

	}

}
