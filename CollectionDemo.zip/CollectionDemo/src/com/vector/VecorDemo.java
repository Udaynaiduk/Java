package com.vector;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

public class VecorDemo {

	public static void main(String[] args) {
		
		Vector<String> v=new Vector<>();
		
		v.add("List");
		v.add("Set");
		v.add("Map");
		v.add("Queue");
		
		// AL LL --> itr list iterator
		// li.iterator() --> Iterator
		// li.listIterator --> ListIterator
		
		// v.elements() --> Enumerator
		
		
		Enumeration<String> enumerator = v.elements();
		while(enumerator.hasMoreElements()) {
			System.out.println(enumerator.nextElement());
		}
		
// Duplicates --> Yes
		// insertion order --> Yes
		
		//Stack -- LIFO
		//Queue -- FIFO
		
	}

}
