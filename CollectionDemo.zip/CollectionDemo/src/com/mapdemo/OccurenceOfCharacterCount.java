package com.mapdemo;

import java.util.HashMap;
import java.util.Map;

public class OccurenceOfCharacterCount {

	public static void main(String[] args) {
		String name = "ABBBCCCCDDDDD";
// A - 2
// B - 3
// C - 4
// it should not be N square complexity
		Map<Character, Integer> map = new HashMap<>();
		char[] nameArray = name.toCharArray();
		for (char c : nameArray) {
			if (map.get(c) == null) {
				map.put(c, 1);
			} else {
				Integer value = map.get(c);
				map.put(c, value + 1);
			}
		}
		System.out.println(map);
	}

}
