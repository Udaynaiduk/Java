package com.set;

import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {

		Map<Integer, String> empData = new HashMap<>();
		empData.put(1, "Upendra");
		empData.put(2, "K");
		empData.put(3, "M");
		empData.put(1, "Siva");
		
		System.out.println(empData.containsKey(11));
		
		Set<Integer> keySet = empData.keySet();
		Collection<String> values = empData.values();
		
		for (String val : values) {
			System.out.println(val);
		}
		System.out.println("_____________");
		for (Integer key : keySet) {
			System.out.println("key is "+key+" value is "+empData.get(key));
		}

		System.out.println(empData);
		System.out.println(empData.get(4));

	}

	private static void treeSet() {
		Set<String> treeSet = new TreeSet<>((s1, s2) -> s1.compareTo(s2));
		treeSet.add("EFGH");
		treeSet.add("A");
		treeSet.add("a");

		System.out.println(treeSet);
	}

	private static void comparator() {
		Comparator<Emp> c = new Comparator<Emp>() {

			@Override
			public int compare(Emp e1, Emp e2) {

				return e1.id > e2.id ? 1 : -1;
			}
		};

		Set<Emp> empList = new TreeSet<>(c);
		Emp e1 = new Emp(1, "A");
		Emp e2 = new Emp(13, "C");
		Emp e3 = new Emp(0, "B");
		Emp e4 = new Emp(19, "B");

		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);

		System.out.println(empList);
	}

	private static void sortByTreeSet() {
		String s1 = "A";// 96354 //abc
		String s2 = new String("AB");// 96354 //def
		Set<String> set = new TreeSet<>();
		set.add(s1);
		set.add(s2);
		set.add("C");
		set.add("Z");
		set.add("B");
		set.add("B");

		System.out.println(set);

		System.out.println(set.contains("abcd"));
		System.out.println(set.contains("upendra")); // o(1)
		// o(N)linear search
		// set
		// upendra --> hash value ---> index
	}

	private static void empDemoWithHash() {
		String s1 = "abc";// 96354 //abc
		String s2 = new String("abc");// 96354 //def
		Set<String> s = new HashSet<>();
		s.add(s2);
		s.add(s1);
		System.out.println(s);
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		Set<Emp> empList = new LinkedHashSet<>();
		Emp e1 = new Emp(1, "Upendra");
		System.out.println("e1.hashCode() is " + e1.hashCode());
		Emp e2 = new Emp(1, "Upendra");
		Emp e3 = new Emp(2, "Ravi");
		System.out.println("e2.hashCode() is " + e2.hashCode());
		System.out.println("e3 hashcode is " + e3.hashCode());
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);

		System.out.println(empList);
	}

	private static void addINSet() {
		Set<String> set = new HashSet<>();
		set.add("123");
		set.add("123");
		set.add("Hi");
		set.add("Hi");
		set.add("Hello");
		set.add("Hello");
		set.add("Bye");

		Iterator<String> iterator = set.iterator();

		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}

		System.out.println(set);
	}

}

class Emp implements Comparable<Emp> {
	int id;

	String name;

	public Emp(int id, String name) {
		this.id = id;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Emp [id=" + id + ", name=" + name + "]";
	}

	@Override
	public int hashCode() {
		return id;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Emp other = (Emp) obj;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	@Override
	public int compareTo(Emp incomingObject) {
		return this.name.compareTo(incomingObject.name);
	}

}
