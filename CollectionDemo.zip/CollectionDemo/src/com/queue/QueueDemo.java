package com.queue;

import java.util.*;

class QueueDemo {
	public static void main(String args[]) {
		PriorityQueue<String> q = new PriorityQueue<String>();
		q.add("A");
		q.add("B");
		q.add("C");
		q.add("D");
		q.add("E");

		String peek = q.peek();//E A

		System.out.println(peek);
		System.out.println(q);
		String poll = q.poll(); // A
		System.out.println(poll);
		System.out.println(q);

	}
}