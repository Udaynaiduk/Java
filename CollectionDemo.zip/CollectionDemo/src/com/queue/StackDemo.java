package com.queue;

import java.util.Stack;

public class StackDemo {

	public static void main(String[] args) {

		Stack<String> stack = new Stack<>();
		stack.add("1");
		stack.add("2");
		stack.push("3");

//		System.out.println(stack);

		// wont remove from stack
//		System.out.println(stack.peek());
		
		// will remove from stack
		// 3 2 1
		stack.pop(); // 2 1
		stack.pop();// 1
		System.out.println("Popped data is "+stack.pop()); // 1
		stack.push("4");
		stack.push("5");
		stack.pop();
		System.out.println(stack);

	}

}
