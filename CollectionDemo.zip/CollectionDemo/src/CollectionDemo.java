import java.util.ArrayList;
import java.util.LinkedList;

public class CollectionDemo {

	public static void main(String[] args) {
		LinkedList<String> names=new LinkedList<>();
		names.add("Vamsi");//String
		names.add("Yashwanth");
		names.add("Tharak");
		
		// iterator list iterator 
		
		System.out.println("******");
		for (String temp : names) {
			System.out.println(temp.toUpperCase());
		}
		System.out.println("****");
		
		String string = names.get(0);
		
		ArrayList<Integer> al2=new ArrayList<>();
		al2.add(1);
		
		ArrayList<Boolean> al3=new ArrayList<>();
		al3.add(false);
		
		ArrayList<Employee> al5=new ArrayList<>();
		al5.add(new Employee(12));
		al5.add(new Employee(15));
		
		
		
		
		// names --> 0th String
		// second elemnt data String
		
		// for loop 
		
		// for each loop <Generics>
		String stringObject1 =(String) names.get(0);
		System.out.println(stringObject1.toUpperCase());


	}

	private static void ArrayvsLinkedList() {
		LinkedList l = new LinkedList();
		l.add("Ramesh");
		l.add("Suresh");
		l.add("Srinu");
		
		int[] b;// int 
		String[] s;//
		Object[] o;// Any object
		//Employee 
		// Object o=new Employee();

		ArrayList l2 = new ArrayList();
		l2.add("Ramesh");
		l2.add("Suresh");
		l2.add("Srinu");

		System.out.println(l);
		l.remove("Ramesh");
		System.out.println("After removal");
		System.out.println(l);
	}

	private static void removal() {
		ArrayList al = new ArrayList<>();
		al.add("Ramesh");
		al.add("Suresh");
		al.add("Hareesh");
		System.out.println("No altering al data is ");
		System.out.println(al);
		al.remove(0);
		al.remove("Hareesh");
		al.add("Srinu");
		System.out.println(" altering al data is ");
		System.out.println(al);
	}

	private static void readOps() {
		ArrayList al1 = new ArrayList(100);

		al1.add(1); // Objects
		al1.add(2); // int
		al1.add(2);// int data
		al1.add(1, "Upendra"); // string data
		al1.add(false);// boolean
		al1.add(12.3); // float Objects
		// float Float primitive to Wrapper conversion

		System.out.println("AL2 data is ");
		ArrayList al2 = new ArrayList(al1);
		System.out.println(al2);

		for (int i = 0; i < 5; i++) {
			System.out.println(al1.get(i));
			System.out.println("**");
			// sc
			// al.add() //
		}

		// Read
		System.out.println(al1.get(0));
		System.out.println(al1.get(1));
		System.out.println(al1.get(2));
		System.out.println(al1.get(3));
		System.out.println(al1.get(4));
		System.out.println(al1.get(5));
	}

	private static void createArrayList() {
		// arrys

		// array list

		// faster ?? Arrays
		// arrays C
		// Collection
		// List
		// ArrayList

		int[] a = { 1, 2, 3 };
		// 3 0-2
		// at first index and push data backwards

		ArrayList a1 = new ArrayList();

		// prefereed
		ArrayList a2 = new ArrayList(100);

		// Insertion order preserved
		// Duplicated accepted
		ArrayList upendraAl = new ArrayList(100);
		upendraAl.add(1);
		upendraAl.add(2);
		upendraAl.add(2);// int data
		upendraAl.add(1, "Upendra"); // string data
		upendraAl.add(false);
		upendraAl.add(12.3);

		// 3rd overloaded constructor
		ArrayList studentAL = new ArrayList();
		System.out.println("Is empty ?? " + studentAL.isEmpty());
		studentAL.add("Student");

		System.out.println(upendraAl);
		System.out.println("--------");
		System.out.println(studentAL);
		studentAL.addAll(1, upendraAl);
		System.out.println("******");
		System.out.println(studentAL);
		System.out.println(studentAL);

		// Create
	}

}
