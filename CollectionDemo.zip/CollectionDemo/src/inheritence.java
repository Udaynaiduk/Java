public class inheritence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		b ab = new b(0);
		ab.se();

	}

}

class a {
	a(int b) {
		System.out.println("i am cons");
	}
}

class b extends a {
	b(int b) {
		super(b);
	}

	public void se() {

	}

}
