package com.transfers;

public class ForEachDemo {

	public static void main(String[] args) {
		
		
		int[] a= {1,2,3};
		// index tho play 
		for (int i : a) {
			System.out.println(i);
		}// AIOBE ???
		
		char[] c = { 'A', 'B', 'C' };
		// traverse an array linearly

		for (char temp : c) {
			System.out.println(temp);
			// temp[2]
		}
		
		System.out.println("*******");
		
		for (int i = 2; i < c.length-2; i++) {
			System.out.println(c[i]);
		}
	}

}
