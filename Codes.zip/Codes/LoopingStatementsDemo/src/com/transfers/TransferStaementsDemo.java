package com.transfers;

public class TransferStaementsDemo {

	public static void main(String[] args) {

		for (int i = 1; i <= 5; i++) {
			// continue break 
			if(i == 3) {
				continue; // just current iteration skip chestundhi
//				break; // breaks the loop 
			}
			System.out.println(i);
		}
	}

}
