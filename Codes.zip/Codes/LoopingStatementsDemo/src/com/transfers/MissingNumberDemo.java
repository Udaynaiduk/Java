package com.transfers;

public class MissingNumberDemo {

	public static void main(String[] args) {
		

		int[] a = { 5, 1, 4, 3,2,7,10,9,8 };// 2 (1-5)
		int arrayValuesSum = 0;
		
		for (int i = 0; i < a.length; i++) {
			arrayValuesSum = arrayValuesSum + a[i];
		}

		System.out.println(arrayValuesSum);

		int actualTotalSum = 10 * (10 + 1) / 2;

		System.out.println(actualTotalSum);
		System.out.println("Missing number is " + (actualTotalSum - arrayValuesSum));
	}

}
