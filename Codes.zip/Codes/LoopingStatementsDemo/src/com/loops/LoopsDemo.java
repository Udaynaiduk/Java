package com.loops;

import java.util.Scanner;

public class LoopsDemo {

	public static void main(String[] args) {

// WAP TO find given number is prime number or not	
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number to check ");
		int nc = sc.nextInt();
		int factorsCount = 0;
		int loopCounter = 0;
		if (nc % 2 == 0) {
			System.out.println("Given number is not prime");
		} else {
			for (int i = 2; i <= Math.sqrt(nc); i++) {
				if (nc % i == 0) {
					factorsCount++;// Alt shift R
				}
				loopCounter++;
				System.out.println(loopCounter);
			}
			if (factorsCount == 0) {
				System.out.println("Given number is Prime Number");
			} else {
				System.out.println("Given number is not prime");
			}
		}
	}

	private static void forLoopDemo() {
		for (int i = 2; i <= 10; i++) {
			if (i % 2 == 0) {
				System.out.println("Even number " + i);
			} else {
				System.out.println("Odd number" + i);
			}
		}
	}

	private static void doWhileDemo() {
		// DO While
		int i = 1;
		do {
			System.out.println(i);
			i++;
		} while (i <= 10);
	}

	private static void whileLoopDemo2() {
		// first 100 lopu even numbers
		int i = 2; // assignment operator

		while (i <= 6) {

			if ((i % 2 == 0)) {
				System.out.println(i);
			}
			i++;
		}
	}

	private static void whileDemoOne() {
		System.out.println("Good eveing");
		System.out.println("Good eveing");
		System.out.println("Good eveing");
		System.out.println("Good eveing");
		System.out.println("Good eveing");

		System.out.println("-------------");

		// Looping statements
		// while
		// do while
		// for
		// for each ( Arrays / Collections )

		// TODO rules
		// Int... index
		// test the conditon
		// Update the index

		// print first 5 numbers

		// While loop
		int i = 1; // 1st
		while (i <= 100) { // 2nd rule
			System.out.println("Good eveing " + i);
			++i;
		}
	}

}
