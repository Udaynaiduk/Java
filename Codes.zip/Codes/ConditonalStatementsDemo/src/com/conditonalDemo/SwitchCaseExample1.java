package com.conditonalDemo;

public class SwitchCaseExample1 {
	public static void main(String args[]) {
		
		String name="Ramesh";
		
		if(name.equals("Ramesh")) {
			System.out.println("Hi ramesh");
		}
		else {
			System.out.println("Hi suresh");
		}

		String role = "CFO";
		switch (role) {
		case "CFO":
			System.out.println("CFO logged in");
//			break;
		case "CTO":
			System.out.println("CTO logged in");
//			break;
		case "CEO":
			System.out.println("CEO logged in");
			break;
		default:
			System.out.println("NA");

		}

	}

	private static void switchExample() {
		int num = 25;
		switch (num) {
		case 1:
			System.out.println("Case1: Value is: " + num);
			break;
		case 2:
			System.out.println("Case2: Value is: " + num);
			break;
		case 3:
			System.out.println("Case3: Value is: " + num);
			break;
		default:
			System.out.println("Default: Value is: " + num);

		}
	}
}