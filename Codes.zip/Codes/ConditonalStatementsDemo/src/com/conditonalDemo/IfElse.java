package com.conditonalDemo;

import com.conditonalDemo2.A;

public class IfElse {

	public static void main(String[] args) {
		A aob=new A();
		System.out.println(aob.yash);
		int a = 99;

		if (a % 2 == 0) {
			System.out.println("Even");
		} else {
			System.out.println("Odd");
		}
	}

}
