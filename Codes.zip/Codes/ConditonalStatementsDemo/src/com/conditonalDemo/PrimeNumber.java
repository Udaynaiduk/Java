package com.conditonalDemo;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {

		// WAP TO find given number is prime number or not
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number to check ");
		int n = sc.nextInt();
		int factorsCount = 0;
		int loopCounter = 0;
		if (n % 2 == 0) {
			System.out.println("Given number is not prime");
		} else {
			for (int i = 2; i <= Math.sqrt(n); i++) {
				if (n % i == 0) {
					factorsCount++;// Alt shift R
					break;
				}
				loopCounter++;
				System.out.println(loopCounter);
			}
			if (factorsCount == 0) {
				System.out.println("Given number is Prime Number");
			} else {
				System.out.println("Given number is not prime");
			}
		}

	} //main closure

}
