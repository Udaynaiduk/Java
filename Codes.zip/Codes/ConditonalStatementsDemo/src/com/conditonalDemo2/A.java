package com.conditonalDemo2;

public class A {
	
	public int yash=200;
	

}
