package com.scanner;

import java.util.Scanner;

public class ScannerDemo {

	public static void main(String[] args) {
		// Just i have created scanner object here
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter u r fav num !!");
		// a value should be dynamically loaded
		int myFavNumber=sc.nextInt();
		
		System.out.println("Please enter another fav number");
		
		int mysecondFavNumber=sc.nextInt();
	
		
		System.out.println("Your fav number is "+myFavNumber);
		
		System.out.println("mysecondFavNumber "+mysecondFavNumber);

	}

}
