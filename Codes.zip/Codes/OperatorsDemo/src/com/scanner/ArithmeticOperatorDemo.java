package com.scanner;

public class ArithmeticOperatorDemo {
	public static void main(String args[]) {
		int a=10; // assignment operator
		a+=10; //20 a=a+10
		a-=10; // 
		a*=10;
		
		System.out.println(a);
		
	}

	public static void myArithmeticExampleCode() {
		int num1 = 100;
		int num2 = 20;
		System.out.println("num1 + num2: " + (num1 + num2));
		System.out.println("num1 - num2: " + (num1 - num2));
		System.out.println("num1 * num2: " + (num1 * num2));
		System.out.println("num1 / num2: " + (num1 / num2));
		System.out.println("num1 % num2: " + (num1 % num2));
	}
}