package com.scanner;

public class TerinaryOperatorsDemo {

	public static void main(String[] args) {
		int num=99;//6 9+9=18 1+8=9
		int sumOfDigits= num%9 ==0 ?9 :num%9;
		System.out.println("Sum of digits is "+sumOfDigits);
	}

	private static void highestOf3() {
		int a = 10;
		int b = 20;
		int c = 300;
		int highestNumber = (a>b&&a>c) ? a : (b > c ? b : c);
		System.out.println(highestNumber);
	}

	 static void highestAmongThree() {
		int a = 100;
		int b = 2000;
		int c = 30;
		int fHN = (a > b) ? a : b;// 2000
		int highestNumber = fHN > c ? fHN : c;
		System.out.println("Highest number is " + highestNumber);
	}

}
