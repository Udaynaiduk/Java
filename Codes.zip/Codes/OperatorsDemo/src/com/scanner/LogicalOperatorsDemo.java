package com.scanner;

import java.util.Scanner;

public class LogicalOperatorsDemo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to Masthan IT Solutions !!!");
		System.out.println("Please enter age");
		int age = sc.nextInt();
		System.out.println("Please enter passport number");
		int passportNum = sc.nextInt();

		boolean isAgeValid = age > 18;

		boolean isValidPassport = passportNum > 5;

		if (!(isAgeValid || isValidPassport)) {
			System.out.println("Go for voting");
		} else {
			System.out.println("Sorry you are not allowed to vote");
		}
	}

}
