package com.scanner;

import java.util.Scanner;

public class AddingTwoNumbers {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		int milkPacket=30;
		
		int noOfpackets=sc.nextInt();
		
		System.out.println("Bill is "+(milkPacket*noOfpackets));
		String s1=sc.nextLine();
		
		System.out.println(s1);
		
		

	}

	private static void flmCalc(Scanner sc) {
		System.out.println("Welcome to FLM Calc !!");
		System.out.println("Enter u r first num to add");
		long firstNumber=sc.nextLong();
		System.out.println("Enter u r second num to add");
		long secondNumber=sc.nextLong();
		long result=firstNumber+secondNumber;
		System.out.println("Result is "+result);
//		char c=sc.nextChar();
		boolean b=sc.nextBoolean();
	}

	private static void msclnsMethod(Scanner sc) {
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		int c=a%b;
		
		System.out.println(c);
	}

}
