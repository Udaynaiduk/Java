package com.scanner;

public class FlowControlStatement {

	public static void main(String[] args) {
		int a=200;
		int b=300;
		if(a == b) {
			
		}

	}

	private static void simpleIfElse() {
		int a = 1000;
		int b = 200;
		int c = 2000;

		if (a > b) {
			if (a > c) {
				System.out.println("A is highest");
			}
		}
	}
}
