package com.scanner;

public class AssignmentOperatorDemo {
	public static void main(String args[]) {
		
		int a=10;
		int b=20;
		 b=a;
		 
		 System.out.println(b);
		
		
	}

	 static void assignmentDemo() {
		int a = 10;
		int b = 20;
		b = a; // b=20 b=30 b=a b == a
		System.out.println("= Output: " + b);
		b += a;
		System.out.println("+= Output: " + b);
		b -= a;
		System.out.println("-= Output: " + b);
		b *= a;
		System.out.println("*= Output: " + b);
		b /= a;
		System.out.println("/= Output: " + b);
		b %= a;
		System.out.println("%= Output: " + b);
	}
	
	 static void wish() {
		 System.out.println("Helllllooo");
	 }
}