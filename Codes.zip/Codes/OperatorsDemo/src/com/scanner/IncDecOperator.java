package com.scanner;

public class IncDecOperator {
	
	

	public static void main(String[] args) {
		
		int a=10;
		System.out.println(a++);// 10
		System.out.println(++a);//12
		System.out.println(--a);//11
		System.out.println(a--);//11
		System.out.println(a);//10

	}

}
