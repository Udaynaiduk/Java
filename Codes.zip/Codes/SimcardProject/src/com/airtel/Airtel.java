package com.airtel;

import com.trai.Sim;

public class Airtel implements Sim {

	@Override
	public String call(int receiverNumber) {
		if (receiverNumber > 0) {
			return "Call connected via Airtel";
		} else {
			return "Call disconnected";
		}
	}

	@Override
	public boolean sendSMS(int rxNumber) {
		if (rxNumber > 0) {
			m6();
			return true;
		}
		return false;
	}

	@Override
	public String data(String typeOfConnection) {
		return typeOfConnection + " data provided by Airtel";
	}

	void m6() {
		// does he have 
		System.out.println("m6 tower logic");
	}

}
