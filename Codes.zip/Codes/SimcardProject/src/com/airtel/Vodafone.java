package com.airtel;

import com.trai.Sim;

public class Vodafone implements Sim{

	@Override
	public String call(int receiverNumber) {
		m7();
		return "Vodafone";
	}

	@Override
	public boolean sendSMS(int rxNumber) {
		return false;
	}

	@Override
	public String data(String typeOfConnection) {
		// TODO Auto-generated method stub
		return "Vodafone 5g";
	}

	void m7() {
		System.out.println("M7");
	}

}
