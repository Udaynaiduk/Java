package com.mobile;

import com.jio.Jio;
import com.trai.Sim;

public class Phone {

	public static void main(String[] args) {
		Sim sim = new Jio ();
		System.out.println(sim.call(123));
		System.out.println(sim.sendSMS(1234));
		System.out.println(sim.data("5G"));
	}

}
