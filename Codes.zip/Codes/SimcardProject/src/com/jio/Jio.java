package com.jio;

import com.trai.Sim;

public class Jio implements Sim {

	public String call(int receiverNumber) {
		if (receiverNumber == 1 || receiverNumber >= 0) {
			return "Call connected via Jio";
		}
		else {
			return "Jio call failed";
		}
	}

	public boolean sendSMS(int rxNumber) {
		boolean result = rxNumber > 123;
		return result;
	}

	public String data(String typeOfConnection) {
		return typeOfConnection+" provided by Jio";
	}

}
