package com.trai;

public interface Sim {

	public static final double SAR = 1.8; //

	// call

	String call(int receiverNumber);

	// sms

	boolean sendSMS(int receiverNumber);

	// data
	String data(String typeOfConnection);

}
