package com.multiinher;

public class C implements A,B {
	
	public static void main(String[] args) {
		int[] a= {1,2};
		System.out.println(a[2]);
	}

	@Override
	public void m1() {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
