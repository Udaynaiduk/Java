package com.multiinher;

public interface B {
	
	void m1();

}
