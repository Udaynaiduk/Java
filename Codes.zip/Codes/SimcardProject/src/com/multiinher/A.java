package com.multiinher;

public interface A {
	
	void m1();

}
