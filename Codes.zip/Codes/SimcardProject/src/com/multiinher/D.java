package com.multiinher;

public interface D extends A,B{
	
	// class to class extends
	// interface to interface extends
	// interface to class implements

}
