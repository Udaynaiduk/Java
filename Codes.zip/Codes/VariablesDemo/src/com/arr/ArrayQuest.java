package com.arr;

public class ArrayQuest {

	public static void main(String[] args) {
		String name="Upendra";
		// This below will convert string namee to array of characters
		char[] nameArray = name.toCharArray();
		int st=0;
		int end=nameArray.length-1;
		char temp;
		
		while(st<=end) {
			// below 3 lines will do swap
			temp=nameArray[st];
			nameArray[st]=nameArray[end];
			nameArray[end]=temp;
			st++;
			end--;
		}
		
		printArrayData(nameArray);
		

	}

	 static void optimisedCodeReverseAnArray() {
		int[] arr = { 1, 2, 3, 4, 5, 6, 7 ,8};
		int start = 0;
		int end = arr.length - 1;
		int temp;
		int counter = 0;

		while (start <= end) { // n/2
			temp = arr[start];
			arr[start] = arr[end];
			arr[end] = temp;
			start++;
			end--;
			counter++;
		}
		System.out.println("Loop itr count " + counter);
	}

	static void nonOptimalWorkingCode() {
		int[] inputArray = { 1, 2, 3, 4, 5 };
		//
		int[] revereArray = new int[inputArray.length];
		int j = 0; // N SC

		// reverse array lo ki data push
		for (int i = inputArray.length - 1; i >= 0; i--) {
			revereArray[j] = inputArray[i];
			j++;
		}

		// reverse array -- input array data copy
		for (int i = 0; i < revereArray.length; i++) {
			inputArray[i] = revereArray[i];
		}

		// print
		System.out.println(inputArray[0]);
	}

	private static void printArrayData(char[] someArray) {
		System.out.println("Array printing begin");
		for (char i : someArray) {
			System.out.println(i);
		}
		System.out.print("Array printing over");
	}

}
