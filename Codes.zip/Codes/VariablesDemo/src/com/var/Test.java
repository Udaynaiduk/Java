package com.var;

public class Test {

	public int x;

	private int y;

	static int z;

	public static void main(String[] args) {
		// To access static var/method use class name
		System.out.println(Test.z);
		Test.m1();

		Test t = new Test();
		System.out.println(t.y);
		System.out.println(t.x);
		System.out.println(Test.z);// static variable

	}

	private static void msclns1() {
		System.out.println("******");
		System.out.println(z);
		Test t = new Test();
		t.x = 250;
		t.y = 350;

		Test t1 = new Test();
		t1.x = 333;
		t1.y = 444;
		System.out.println(t.x);
		System.out.println(t.y);
		System.out.println("---------");
		System.out.println(t1.x);
		System.out.println(t1.y);
		
		t.m2();
	}

	static void m1() {
		System.out.println("I am static m1 method!!");
	}
	
	void m2() {
		System.out.println("I am a non static method");
	}
}
