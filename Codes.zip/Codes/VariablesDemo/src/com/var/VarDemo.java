package com.var;

public class VarDemo {
	int val = 2;// instance var

	public static void main(String[] args) {
		VarDemo v = new VarDemo(); // v object ref
		v.m1();

	}

	 void m1() {
		System.out.println(val);
	}

	static void m2() {
		int y = 350;
		System.out.println("C");
		System.out.println("CCC");
	}

}
