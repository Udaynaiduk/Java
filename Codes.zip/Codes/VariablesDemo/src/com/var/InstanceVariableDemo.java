package com.var;

public class InstanceVariableDemo {
	
	// Banking Application
	
	// Home loan
	
	// car loan
	
	// personal loan
	
	// GST
	int gst;// 1 declare and init
	// 2 constructor
	// 3 getter and setters OOP --> Encapsulation
	// 4 obj ref
	
	
	int homeLoan() {
		double homeLoanRate=0.3;
		System.out.println(gst);
		double loanAmount=36000.23;
		return 0;
	}
	
	int carLoan() {
		double carLoanRate=0.3;
		System.out.println(gst);
		double loanAmount=90000.23;
		return 0;
	}
	
	// edu
	
	// nri

	int y = 350; // iv
	
	static int z=450; // class loading

	public static void main(String[] args) {
		
		InstanceVariableDemo ivd=new InstanceVariableDemo();
		ivd.gst=18;// 4th way
		System.out.println(ivd.gst);
		
		
		
		System.out.println(z);
		
		int x = 230; // lv

		// a b
		int a = 100;
		int b = 200;
		System.out.println("A value is " + a);
		System.out.println("B value is " + b);
		System.out.println("After swap logic");
		// swap the values

		int temp = a; // SC a=b; b=temp;

		a = a + b;
		b = a - b;
		a = a - b;
		System.out.println("A value is " + a);
		System.out.println("B value is " + b);

	}

	static void m1() {
		System.out.println("I am M1 method");
	}

	void m2() { // obj creation 
		System.out.println("I am M1 method");
		System.out.println(y);
		System.out.println(z);
	}

}
