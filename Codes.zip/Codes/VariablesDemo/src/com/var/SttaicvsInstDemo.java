package com.var;

public class SttaicvsInstDemo {

	int x; // iv 

	static int z; // sv

	public static void main(String[] args) {
		Test t1 = new Test(); // lv
		t1.x = 100;
		Test.z=200;

	}

}
