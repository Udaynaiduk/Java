package com.var2;

public class SttaicvInt {
	
	int myInstaceVariable;
	
	static  int z=200;

	public static void main(String[] args) {
		SttaicvInt x1=new SttaicvInt();
		x1.z=299;
		SttaicvInt x2=new SttaicvInt();
		SttaicvInt x3=new SttaicvInt();
		SttaicvInt x4=new SttaicvInt();
		SttaicvInt x5=new SttaicvInt();
		System.out.println(x1.z);
		System.out.println(x2.z);
		System.out.println(x3.z);
		System.out.println(x4.z);
		
		
	}

	private static void m11() {
		SttaicvInt t1=new SttaicvInt();
		t1.myInstaceVariable=100;
		t1.z=101;
		System.out.println(t1.myInstaceVariable); // 100
		System.out.println(t1.z); // 101 
		
		SttaicvInt t2=new SttaicvInt();
		t2.myInstaceVariable=200;
		t2.z=102;
		
		System.out.println(t2.myInstaceVariable); // 200 
		System.out.println(t2.z); // 102 
		System.out.println("*******");
		System.out.println(SttaicvInt.z); // 101
		
		SttaicvInt.z=999999;
		System.out.println("&&&&&&&&");
		System.out.println(SttaicvInt.z);
	}

}
