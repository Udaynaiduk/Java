package com.abs;

public abstract class Employee {

	public static void main(String[] args) {
	}

	void writeCode() {
		System.out.println("Employee writing code");
	}



}
