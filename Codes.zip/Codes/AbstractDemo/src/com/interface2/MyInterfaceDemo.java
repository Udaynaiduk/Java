package com.interface2;

public interface MyInterfaceDemo {
	
	 int a=250;
	
	 void m1();
	 
	

}
