package com.interface2;

public class ChildClass implements MyInterfaceDemo{

	@Override
	public void m1() {
		System.out.println("M1 implemented");
	}
	
	public static void main(String[] args) {
		MyInterfaceDemo c=new ChildClass();
		c.m1();
	}

}
