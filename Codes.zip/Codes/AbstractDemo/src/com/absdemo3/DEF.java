package com.absdemo3;

public  abstract class DEF extends ABC{
	
	// m2 and m3
	
	@Override
	void m2() {
		System.out.println("DEF m2 impl");
	}
	

	
	public static void main(String[] args) {}
	
}
