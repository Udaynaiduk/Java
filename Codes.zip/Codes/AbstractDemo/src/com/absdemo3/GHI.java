package com.absdemo3;

public class GHI extends DEF {

	@Override
	public void m3() {
		System.out.println("GHI m3 impl");
	}

	public static void main(String[] args) {
		ABC g = new GHI();
		g.m1();
		g.m2();
		g.m3();
		g.m5();
	}
	
	@Override
	void m5() {
		System.out.println("m5 from GHI");
	}

}
