package com.absdemo3;

public abstract class ABC {
	
	public static final int x=200;
	
	public void m1(){
		System.out.println("ABC m1");
	}
	
	abstract void m2();
	
	public abstract void m3();
	
	public static void main(String[] args) {
		GHI obj=new GHI();
		obj.m1();
		obj.m2();
		obj.m3();
	}
	
	 void m5() {
		 System.out.println("Abc m5");
	 }

}
