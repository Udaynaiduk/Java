package com.absdemo2;

public abstract class NASAHacking {
	
	// 1 2
	
	void authenticationBreak() {
		System.out.println("user name password given hacked");
	}
	
	abstract void systemMalfunction();
	
	public static void main(String[] args) {
		
	}
	
	

}
