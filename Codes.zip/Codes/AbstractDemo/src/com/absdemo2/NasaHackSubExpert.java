package com.absdemo2;

public abstract class NasaHackSubExpert extends NASAHacking {

	@Override
	void systemMalfunction() {
		System.out.println("system mal function executed");
	}

	public static void main(String[] args) {}

}
