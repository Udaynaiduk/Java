package com.arrays;

public class ArrayDemo {

	public static void main(String[] args) {

		int a = 10;
		int b = 20;

		int t = a;
		a = b;
		b = t;

		System.out.println(a);
		System.out.println(b);

		
	}

}
