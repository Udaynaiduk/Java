package com.arrays;

import java.util.Scanner;

public class ArrayArgsDemo {
	
	int val=2;// instance var

	public static void main(String[] args) {
		localVarDemo();
	}

	private static void localVarDemo() {
		int result = sumOfNumbers(5,10,15,25,30,40);
		System.out.println(result);
		
		if(result < 2) {
			System.out.println("Hello");
		}
		else {
			
		}
	}

	private static void runTimeArgs(String[] args) {
		String value="1";
		int a=1;
		System.out.println(value);
		System.out.println(a);
		
		// DB connection
		// user name pw url ip
		System.out.println(args[0]);
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter array size");
		int size = sc.nextInt();
		int[] b = new int[size];
		for (int i = 0; i < size; i++) {
			System.out.println("Enter " + i + " th ele");
			b[i] = sc.nextInt();
		}


		int output = sumOfArrayElem(b);
		System.out.println(output);
	}

	// array lo elem sum res ret

	// input - array x
	// output - sium of array digits
	// expectaion

	static int sumOfArrayElem(int[] www) {
		int sum =0;// local var
		for (int i = 0; i < www.length; i++) {
			sum = sum + www[i];
		}

		return sum;

	}

	private static void sumOfTwoNumbers() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first num");
		int firsta = sc.nextInt();
		System.out.println("Enter second num");
		int secondAr = sc.nextInt();
		int res = sumOfNumbers(firsta, secondAr);
		System.out.println(res);// Alt shift r
		// codef ormat
		// Alt shift f
		// rename
		// alt shift r
	}

	// void return
	// return void

	static int sumOfNumbers(int... a) {
		int result = 0;
		for (int i = 0; i < a.length; i++) {
			result=result+a[i];
		}
		return result;

	}
	
	void m4() {
		System.out.println(val);
	}

}
