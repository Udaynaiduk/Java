package com.arrays;

import java.util.Scanner;

public class ArraysDemo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

//		char[] c = { 'U', 'P', 'E', 'N', 'D', 'R', 'A' };
		char[] c = { 'A', 'B', 'C' };
		System.out.println("Size of array");
		int size = sc.nextInt();
		int[] d = new int[size];// 0 - 4

		// write data into loop

		for (int i = 0; i < d.length; i++) {
			System.out.println("Enter " + i + "th value ");
			d[i] = sc.nextInt();

		}
		/*
		 * d[0] = 99; d[1] = 199; d[2] = 299; d[3] = 499; d[4] = 699;
		 */
		for (int i = 0; i < d.length; i++) {
			System.out.println(d[i]);
		}
		System.out.println("***********");
		int lengthOfMyArray = c.length;

		// iterate / traverse an array
		for (int i = 0; i < c.length; i++) {
			System.out.println(c[i]);
		}

	}

}
