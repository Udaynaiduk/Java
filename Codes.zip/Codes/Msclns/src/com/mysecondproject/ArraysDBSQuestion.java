package com.mysecondproject;

public class ArraysDBSQuestion {
	static int[] arr = { 1, 2, 3, 4, 5 };

	public static void main(String[] args) {

		reverseArray2(arr);
		System.out.println(arr[0]);

	}

	public static int[] reverseArray(int[] array) {
		int[] reversedArray = new int[array.length];
		int index = 0;

		for (int i = array.length - 1; i >= 0; i--) {
			reversedArray[index] = array[i];
			index++;
		}
		printArray(reversedArray);
		for (int i = 0; i < reversedArray.length; i++) {
			array[i] = reversedArray[i];
		}
		printArray(array);

		return array;

	}

	public static void reverseArray2(int[] array) {
		int start = 0;
		int end = array.length - 1;

		while (start < end) {
			// Swap elements at start and end positions
			int temp = array[start];
			array[start] = array[end];
			array[end] = temp;

			// Move start and end pointers towards the center
			start++;
			end--;
		}

		printArray(array);
	}

	static void printArray(int[] sourceArray) {
		System.out.println("Array content Printint Begin");
		for (int i : sourceArray) {
			System.out.println(i);
		}
		System.out.println("Array Content print Done");
		System.out.println("----------------------");
	}

}
