package com.mysecondproject;

import java.util.Scanner;

public class datatypes {
	public static void main(String[] args) {
		System.out.println(args[1]);
	}

	private static void extracted() {
		GiftCoupon();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The First Number ");
		int FirstNum = sc.nextInt();
		System.out.println("Enter The Second Number");
		int SecondNum = sc.nextInt();
		int Result = FirstNum + SecondNum;
		System.out.println("Result is " + Result);
	}

	static void GiftCoupon() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Total Bill");
		long Bill = sc.nextLong();
		if (Bill >= 10000000) {
			System.out.println("Eligible For Gift Coupon");
		} else {
			System.out.println("Not Eligible For Coupon");
		}

	}
}
