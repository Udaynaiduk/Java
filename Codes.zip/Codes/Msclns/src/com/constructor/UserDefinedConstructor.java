package com.constructor;

public class UserDefinedConstructor {
	int empIddd; // setting
	int empId;//print
	String empname; // setting
	String ename;//print

	public static void main(String[] args) {
		UserDefinedConstructor uc = new UserDefinedConstructor(22, "pallavi");
		System.out.println("emp id is:" + uc.empId);
		System.out.println("emp name is:" + uc.ename);
	}

	UserDefinedConstructor(int employeeId, String employeeName) {
		this.empId = employeeId;
		this.ename = employeeName;
	}
	
	UserDefinedConstructor(){}
	
	void m1() {
		
	}
	
	void m1(int a) {
		
	}
	
	// multiple const - constructor oveloading
	// same name tho multiple methos - method overlaoding
}