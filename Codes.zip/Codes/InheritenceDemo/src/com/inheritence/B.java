package com.inheritence;

public class B extends A { // SI
	int x = 99;

	public static void main(String[] args) {
		B b = new B();
		b.m1();
	}

	void m1() {
		System.out.println("X val is " + super.x);
		super.preciousMethod();
		System.out.println("B class m1");
	}

	void m2() {
		System.out.println("B class m2");
	}

	B() {
		super(1);
		System.out.println("B class Con");
	}

	void preciousMethod() {
		System.out.println("B precious");
	}

}
