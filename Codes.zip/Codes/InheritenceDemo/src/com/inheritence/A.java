package com.inheritence;

public class A {

	final int x = 9;

	public static void main(String[] args) {
	}

	void m1() {
		System.out.println("A class m1");
		super.toString();
	}

	void preciousMethod() {
		System.out.println("A precious");
	}

	A() {
		System.out.println("A class Constructor");
	}

	A(int a) {
		System.out.println("Parent param cons");
	}

}
