package com.inheritence;

public class C {
	
	public static void main(String[] args) {
		C c=new C();
	}

}
