package com.poly.overriding;

public class Employee {

	int id = 123;

	String name = "Upendra";

	public static void main(String[] args) {
		Employee emp = new Employee();
		System.out.println(emp);
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	}

}
