package com.poly.overriding;

public class Nagarjuna extends ANR {

	static void m2() {
		System.out.println("Nag M2");
	}

	public static void main(String[] args) {
		ANR anr = new ANR();
		Nagarjuna nag = new Nagarjuna();
		ANR nageswarrao2 = new Nagarjuna();
		nageswarrao2.annapurnaStudios();

	}

	void annapurnaStudios() {

		System.out.println("ANR Studios With Iron");
	}

	int startMaaRevenue(int stateCode) {
		return 49999;
	}

}
