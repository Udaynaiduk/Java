package com.poly.overriding;

public class Akhil extends Nagarjuna {

	public static void main(String[] args) {
		Akhil ayyagaru = new Akhil();
		ayyagaru.annapurnaStudios();
	}

	

	int startMaaRevenue() {

		return 50000;
	}
	
	@Override
	int startMaaRevenue(int rev) {
		System.out.println("");

		return 50000;
	}
	

}
