package com.poly.overriding;

public class ANR {
	
	static void m2() {
		System.out.println("ANR M2");
	}

	public static void main(String[] args) {

		ANR anr = new ANR();
		anr.annapurnaStudios();
		String toStringResult = anr.toString();
		System.out.println(toStringResult);

	}

	 void annapurnaStudios() {

		System.out.println("ANR Studios With Penkulu");
	}
	

	 void annapurnaStudios(int a) {

		System.out.println("ANR Studios With Penkulu");
	}

}
