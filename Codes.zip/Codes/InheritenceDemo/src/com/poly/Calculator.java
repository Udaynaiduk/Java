package com.poly;

public class Calculator {

	public static void main(String[] args) {
		Calculator calc = new Calculator();
		int result = calc.sum(10, 20, 30);
		System.out.println("reuslt is " + result);
		temp(28, "Upendra");
		

	}

	// length of args are different - 1
	// order of args different - 2

	static void temp(String name, int age) {
		System.out.println("Name is " + name + " age is " + age);
	}

	static void temp(int age, String name) {
		System.out.println("age is " + age + " name is " + name);

	}

	int sum(int a, int b) {

		return a + b;
	}

	int sum(int a, int b, int c) {
		return a + b + c;
	}

}
