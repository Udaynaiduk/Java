package com.manam;

public class Nagarjuna extends NageswaraRao{
	
	public static void main(String[] args) {
		Nagarjuna nag=new Nagarjuna();
		nag.maaTv();
		nag.annapuraStudios(); // SI
		
	}
	
	void maaTv() {
		System.out.println("Star Tv by Nagarjuna");
	}

}
