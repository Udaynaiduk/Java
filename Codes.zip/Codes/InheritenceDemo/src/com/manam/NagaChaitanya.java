package com.manam;

public class NagaChaitanya extends Nagarjuna{

	public static void main(String[] args) {
		
		NagaChaitanya nc=new NagaChaitanya();
		nc.shoyu();
		nc.maaTv(); // SI
		
		nc.annapuraStudios(); // MLI

	}

	void shoyu() {
		System.out.println("Shoyu restaurant");
	}

}
