package com.manam;

public class NageswaraRao {

	public static void main(String[] args) {
		
		NageswaraRao anr=new NageswaraRao();
		anr.annapuraStudios();
//		anr.maaTv();

	}
	
	void annapuraStudios() {
		System.out.println("ANR Studios");
	}

}
