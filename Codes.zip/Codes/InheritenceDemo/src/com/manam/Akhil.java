package com.manam;

public class Akhil extends Nagarjuna {

	public static void main(String[] args) {
		Akhil ayyagaru=new Akhil();
		ayyagaru.cricketFranchise();
		ayyagaru.maaTv();
		ayyagaru.annapuraStudios();

	}
	
	void cricketFranchise() {
		System.out.println("Telugu Warriors");
	}

}
