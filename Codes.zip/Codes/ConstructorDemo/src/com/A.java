package com;

public class A {
	int a;

	int b;

	public static void main(String[] args) {
		A a = new A("Hi");

	}

	A(int a) {
		this(1, 2);
		System.out.println("a");

	}

	A(int A, int b) {
		System.out.println("b");
	}

	A(String a) {
		this(5);
		System.out.println("c");

	}

}
