package com;

public class Person {
	// 1 2 3 4

	int uid=114; // iv intlz

	Person() {
		System.out.println("Hi , Person How are you ?");
	}

	public static void main(String[] args) {
		Person p = new Person();

	}

	 void m1() {
		System.out.println(this.uid);

	}

	// this

}
