package com;

public class Sim {

	private static final String HI = "HI";

	int aadhar;

	String pan;

	String rationCard;

	public static void main(String[] args) {
		Sim sim1 = new Sim(1223);
		Sim s2 = new Sim("BTE", "RTG");
		
		System.out.println(" " + sim1.aadhar);
		System.out.println(" " + s2.aadhar);

	}

	Sim(int aadahr) { // const i int param
		this(HI,"Bye");
		System.out.println("1A");
		this.aadhar = aadahr;
//		System.out.println("Sim activated");
	}

	Sim(String pan, String rationCard) { // const String String 
		System.out.println("1B");
		this.pan = pan;
		this.rationCard = rationCard;
//		System.out.println("Sima ctivated");
	}

}
