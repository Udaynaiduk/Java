package com;

public class Test {

	public static void main(String[] args) {
		System.out.println("Hi");
		Test t = new Test();
		
	}

	// 1
	// 2
	// 3 no retType
	 Test() {
		System.out.println("Hello i am const");
	}
	 
	 void m1() {}
	 
	 void m2(int a) {}
	 
	 void m3(int a, int b,int c) {}
	 
	 void Test(int a,int b) {}
	 
	 // int char void 
	 // obj

}
