package com;

public class User {
	int xyz; // This to be mandatry int
	int r;
	String name;

	public static void main(String[] args) {
		User u = new User("Upendra");

	}

	void m1() {
	}

	User(int x) {

	}

	User(int y, int z) {

	}

	User(int x, String y, int z) { // 3 

	}

	User(String x, int y, int z) { // 3 

	}

	User(int uid, String name) {
		System.out.println("C");
	}

	User() {
		System.out.println("A");
	}

	User(String a) {
		System.out.println("B");
	} // constructor overloading

}
