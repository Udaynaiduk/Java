package com;

public class Employee2 {

	int id=888; // iv

	String name="Upendra"; // iv
	static int sal;

	public static void main(String[] args) {
		Employee2 e2=new Employee2();
		e2.displayEmployeeDetails();
	}

	void displayEmployeeDetails() {
		int id=999;
		System.out.println("Employee id is " + this.id);
		System.out.println("Name is " + this.name);
		this.sayBye();
	}

	void sayBye() { // instance method
		System.out.println("Bye");
	}

}
