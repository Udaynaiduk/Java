package com;

public class Employee {

	int id;

	public static void main(String[] args) {
		Employee emp = new Employee();
		System.out.println(emp.id);
	}
	
	 Employee() {
		 System.out.println("Emp cons");
	}

}
