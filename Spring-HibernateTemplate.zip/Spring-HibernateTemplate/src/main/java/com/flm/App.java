package com.flm;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.flm.entity.Product;
import com.flm.orm.dao.ProductDAO;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
    	System.out.println("Loaded");
    	ProductDAO productDAO = ctx.getBean("product",ProductDAO.class);
//    	createProduct(productDAO);
//    	productDAO.deleteProduct(70);
//    	getAllProds(productDAO);
//    	Product product = productDAO.getProduct(112);
    	productDAO.updateProduct(new Product(1, 10));
    	System.out.println("Done!!");
    }

	private static void getAllProds(ProductDAO productDAO) {
		List<Product> products = productDAO.getAllProducts();
    	System.out.println(products);
	}

	private static void createProduct(ProductDAO productDAO) {
		Product p=new Product();
		p.setId((int) (Math.random()*100));
		p.setName("TV");
		p.setDesc(com.flm.RandomStringGenerator.generateRandomString(9));
		p.setPrice(Math.random()*100);
    	productDAO.createProduct(p);
	}
}
