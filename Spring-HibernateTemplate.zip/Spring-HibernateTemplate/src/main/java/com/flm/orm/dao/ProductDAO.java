package com.flm.orm.dao;

import java.util.List;

import com.flm.entity.Product;

public interface ProductDAO {
	int createProduct(Product product);

	Product getProduct(int productId);

	List<Product> getAllProducts();

	int updateProduct(Product product);

	int deleteProduct(int prodictId);

}
