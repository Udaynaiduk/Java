package com.flm.orm.dao;

import java.io.Serializable;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import com.flm.entity.Product;
import com.flm.entity.Sale;

@Component("product")
public class ProductDAOImpl implements ProductDAO {

	@Autowired
	HibernateTemplate hibernateTemplate;

	@Override
	@Transactional
	public int createProduct(Product p) {

		int res = (int) hibernateTemplate.save(p);
		return res;
	}

	@Override
	public Product getProduct(int productId) {
		// TODO Auto-generated method stub
		return hibernateTemplate.get(Product.class, productId);
		
	}

	@Override
	public List<Product> getAllProducts() {
		List<Product> allProducts = hibernateTemplate.loadAll(Product.class);
		return allProducts;
	}

	@Override
	@Transactional
	public int updateProduct(Product product) {
		hibernateTemplate.update(product);
		return 1;
	}

	@Override
	@Transactional
	public int deleteProduct(int prodictId) {
		Product product = hibernateTemplate.get(Product.class, prodictId);
		if(product != null) {
		hibernateTemplate.delete(product);
		}
		return 0;
	}

}
