package com.sim;

public interface Sim {
	
	void calling(int number);
	
	void data(String internetType);

}
