package com.sim;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration // beans.xml
@ComponentScan(basePackages = "com")
@PropertySource(value = "classpath:app.properties")
public class UpendraConfig {
	
	

}
