package com.sim;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {

	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(UpendraConfig.class);
		Student student = ctx.getBean("student", Student.class);
		System.out.println(student.name);
		System.out.println(student.id);
		System.out.println(student.adr);
	}

}
